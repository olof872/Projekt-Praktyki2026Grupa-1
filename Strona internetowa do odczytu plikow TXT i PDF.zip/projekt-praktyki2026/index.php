<?php
$text = "";
$fileName = "";
$pdfUrl = "";
$error = "";

$uploadDir = __DIR__ . "/uploads/";

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
    && isset($_FILES["file"])
) {
    $file = $_FILES["file"];
    $extension = strtolower(
        pathinfo($file["name"], PATHINFO_EXTENSION)
    );

    if ($file["error"] !== UPLOAD_ERR_OK) {
        $error = "Nie udało się wczytać pliku.";
    } elseif (!in_array($extension, ["txt", "pdf"], true)) {
        $error = "Dozwolone formaty to TXT i PDF.";
    } elseif ($file["size"] > 5 * 1024 * 1024) {
        $error = "Maksymalny rozmiar pliku to 5 MB.";
    } else {
        $fileName = basename($file["name"]);

        if ($extension === "txt") {
            $text = file_get_contents($file["tmp_name"]);

            if ($text === false) {
                $error = "Nie udało się odczytać pliku.";
            }
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($file["tmp_name"]);

            if ($mime !== "application/pdf") {
                $error = "Wybrany plik nie jest prawidłowym PDF-em.";
            } else {
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }

                $savedName = bin2hex(random_bytes(16)) . ".pdf";
                $destination = $uploadDir . $savedName;

                if (move_uploaded_file(
                    $file["tmp_name"],
                    $destination
                )) {
                    $pdfUrl = "uploads/" . $savedName;
                } else {
                    $error = "Nie udało się zapisać PDF-a.";
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Podgląd plików</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<main class="container">
<iframe id="pdfPreview" title="Podgląd PDF"></iframe> 
    <header class="header">
        <h1>Pliki</h1>
        <p>Wybierz plik TXT lub PDF, aby zobaczyć jego zawartość.</p>
    </header>

    <form method="POST" enctype="multipart/form-data" id="uploadForm">

        <section class="cards">

            <div class="card">
                <div class="card-title">
                    <span class="number">01</span>
                    <div>
                        <h2>Browse</h2>
                        <p>Wybierz plik z komputera</p>
                    </div>
                </div>

                <label for="fileInput" class="browse-box">
                    <span class="file-icon">FILE</span>
                    <span id="fileName">Nie wybrano pliku</span>
                    <span class="browse-button">Przeglądaj</span>
                </label>

                <input
                    type="file"
                    name="file"
                    id="fileInput"
                    accept=".txt,.pdf,text/plain,application/pdf"
                    required
                    hidden
                >
            </div>

            <div class="card">
                <div class="card-title">
                    <span class="number">02</span>
                    <div>
                        <h2>Drop</h2>
                        <p>Przeciągnij i upuść plik</p>
                    </div>
                </div>

                <div class="drop-zone" id="dropZone">
                    <span class="upload-icon">↑</span>
                    <strong>Upuść plik tutaj</strong>
                    <p>Obsługiwane formaty: TXT i PDF</p>
                </div>
            </div>

        </section>

        <button type="submit" class="submit-button">
            Wczytaj plik
        </button>

    </form>

    <?php if ($error): ?>
        <div class="error">
            <?= htmlspecialchars($error, ENT_QUOTES, "UTF-8") ?>
        </div>
    <?php endif; ?>

    <section class="preview">
        <div class="preview-header">
            <h2>03. Podgląd</h2>
            <p id="previewName">
                <?= htmlspecialchars($fileName, ENT_QUOTES, "UTF-8") ?>
            </p>
        </div>

        <pre id="previewText" <?= $pdfUrl ? 'hidden' : '' ?>><?=
            htmlspecialchars(
                $text,
                ENT_QUOTES | ENT_SUBSTITUTE,
                "UTF-8"
            )
        ?></pre>

        <iframe
            id="pdfPreview"
            title="Podgląd pliku PDF"
            src="<?= htmlspecialchars($pdfUrl, ENT_QUOTES, "UTF-8") ?>"
            style="<?= $pdfUrl ? 'display:block;' : 'display:none;' ?>"
        ></iframe>

        <div class="preview-footer">
            <span id="charCount"><?= mb_strlen($text, "UTF-8") ?> znaków</span>
            <button type="button" class="clear-button" id="clearButton">
                Wyczyść
            </button>
        </div>
    </section>

</main>

<script>
const input = document.getElementById("fileInput");
const drop = document.getElementById("dropZone");
const nameLabel = document.getElementById("fileName");
const previewName = document.getElementById("previewName");
const textPreview = document.getElementById("previewText");
const pdfPreview = document.getElementById("pdfPreview");
const charCount = document.getElementById("charCount");

let localPdfUrl = null;

function showFile(file) {
    if (!file) return;

    const ext = file.name.split(".").pop().toLowerCase();

    if (!["txt", "pdf"].includes(ext)) {
        alert("Wybierz plik TXT lub PDF.");
        return;
    }

    nameLabel.textContent = file.name;
    previewName.textContent = file.name;

    if (localPdfUrl) {
        URL.revokeObjectURL(localPdfUrl);
        localPdfUrl = null;
    }

    if (ext === "pdf") {
        textPreview.hidden = true;
        pdfPreview.style.display = "block";
        pdfPreview.src = localPdfUrl = URL.createObjectURL(file);
        charCount.textContent = "Dokument PDF";
        return;
    }

    pdfPreview.style.display = "none";
    pdfPreview.removeAttribute("src");
    textPreview.hidden = false;
    textPreview.textContent = "Wczytywanie...";

    const reader = new FileReader();

    reader.onload = () => {
        textPreview.textContent = reader.result;
        charCount.textContent =
            [...reader.result].length.toLocaleString("pl-PL")
            + " znaków";
    };

    reader.onerror = () => {
        textPreview.textContent = "Nie udało się odczytać pliku.";
    };

    reader.readAsText(file, "UTF-8");
}

input.addEventListener("change", () => showFile(input.files[0]));

drop.addEventListener("click", () => input.click());

["dragenter", "dragover"].forEach(type => {
    drop.addEventListener(type, event => {
        event.preventDefault();
        drop.classList.add("active");
    });
});

["dragleave", "drop"].forEach(type => {
    drop.addEventListener(type, event => {
        event.preventDefault();
        drop.classList.remove("active");
    });
});

drop.addEventListener("drop", event => {
    const file = event.dataTransfer.files[0];
    if (!file) return;

    const transfer = new DataTransfer();
    transfer.items.add(file);
    input.files = transfer.files;

    showFile(file);
});

document.getElementById("clearButton").addEventListener("click", () => {
    input.value = "";
    nameLabel.textContent = "Nie wybrano pliku";
    previewName.textContent = "";
    textPreview.textContent = "";
    textPreview.hidden = false;
    pdfPreview.removeAttribute("src");
    pdfPreview.style.display = "none";
    charCount.textContent = "0 znaków";

    if (localPdfUrl) {
        URL.revokeObjectURL(localPdfUrl);
        localPdfUrl = null;
    }
});
</script>

</body>
</html>