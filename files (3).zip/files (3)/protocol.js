(() => {
  'use strict';

  const $ = id => document.getElementById(id);

  const PDFJS_WORKER = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  const HANDOFF_KEY = 'textTools.handoff';
  const CHUNK_SIZE = 3000; // znaków na jedno zapytanie (num_ctx = 4096)

  const fileInput = $('file');
  const generateBtn = $('generateProtocol');
  const messageBox = $('message');
  const resultSection = $('protocolResult');
  const bodyBox = $('protocolBody');
  const metaBox = $('protocolMeta');
  const pdfBtn = $('downloadPdf');
  const jsonBtn = $('downloadJson');

  let sourceText = '';
  let fileName = 'tekst';
  let protocol = null;

  function setMessage(text, cls = '') {
    if (!messageBox) return;
    messageBox.className = cls;
    messageBox.textContent = text;
  }

  if (window.pdfjsLib) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = PDFJS_WORKER;
  }

  async function callBackend(payload) {
    const res = await fetch('ollama.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    let data = null;
    try { data = await res.json(); } catch (_) { /* nie-JSON */ }

    if (!res.ok || !data || data.error) {
      throw new Error((data && data.error) || `Błąd serwera (HTTP ${res.status}).`);
    }
    return data;
  }

  async function checkOllamaConnection() {
    const connDiv = $('connection');
    if (!connDiv) return;

    connDiv.className = 'status';
    connDiv.textContent = 'Sprawdzanie połączenia z Ollama…';

    try {
      const data = await callBackend({ action: 'health' });
      connDiv.className = 'status success';
      connDiv.textContent = `Połączono z Ollama. Aktywny model: ${data.model}`;
    } catch (err) {
      connDiv.className = 'status error';
      connDiv.textContent = err.message || 'Brak połączenia z Ollama.';
    }
  }

  async function readFile(file) {
    const extension = file.name.split('.').pop().toLowerCase();
    fileName = file.name.replace(/\.[^.]+$/, '') || 'tekst';

    if (extension === 'txt') {
      return file.text();
    }

    if (extension === 'pdf') {
      if (!window.pdfjsLib) {
        throw new Error('Biblioteka PDF.js nie została załadowana. Sprawdź połączenie internetowe.');
      }
      const buffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(buffer) }).promise;
      const pages = [];

      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        pages.push(content.items.map(item => item.str).join(' '));
      }

      const text = pages.join('\n\n');
      if (!text.trim()) {
        throw new Error('PDF nie zawiera warstwy tekstowej (prawdopodobnie skan - wymaga OCR).');
      }
      return text;
    }

    throw new Error('Niedozwolony format pliku. Wybierz plik TXT lub PDF.');
  }

  // Dzieli tekst na fragmenty po granicach zdań, żeby nie ucinać myśli w pół słowa.
  function chunkText(text) {
    const parts = text.split(/(?<=[.!?])\s+|\n+/).map(p => p.trim()).filter(Boolean);
    const chunks = [];
    let current = '';

    const flush = () => {
      if (current.trim()) chunks.push(current.trim());
      current = '';
    };

    for (const part of parts) {
      if (part.length > CHUNK_SIZE) {
        flush();
        for (let off = 0; off < part.length; off += CHUNK_SIZE) {
          chunks.push(part.slice(off, off + CHUNK_SIZE));
        }
        continue;
      }
      if (current.length + part.length + 1 > CHUNK_SIZE) flush();
      current += (current ? ' ' : '') + part;
    }
    flush();
    return chunks;
  }

  function el(tag, text, cls) {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = text; // textContent = brak XSS
    if (cls) node.className = cls;
    return node;
  }

  function addList(title, items) {
    bodyBox.appendChild(el('h3', title));
    if (!items.length) {
      bodyBox.appendChild(el('p', 'Brak informacji w tekście.', 'empty'));
      return;
    }
    const ul = el('ul');
    items.forEach(item => ul.appendChild(el('li', item)));
    bodyBox.appendChild(ul);
  }

  function addActions(items) {
    bodyBox.appendChild(el('h3', 'Zadania do wykonania'));
    if (!items.length) {
      bodyBox.appendChild(el('p', 'Brak informacji w tekście.', 'empty'));
      return;
    }

    const table = el('table');
    const head = el('tr');
    ['Kto', 'Zadanie', 'Termin'].forEach(h => head.appendChild(el('th', h)));
    table.appendChild(head);

    items.forEach(item => {
      const row = el('tr');
      row.appendChild(el('td', item.who || 'nie podano'));
      row.appendChild(el('td', item.task));
      row.appendChild(el('td', item.deadline || 'nie podano'));
      table.appendChild(row);
    });

    const wrap = el('div', undefined, 'table-wrap');
    wrap.appendChild(table);
    bodyBox.appendChild(wrap);
  }

  function renderProtocol() {
    bodyBox.textContent = '';

    addList('Tematy', protocol.topics || []);
    addList('Decyzje i ustalenia', protocol.decisions || []);
    addActions(protocol.action_items || []);
    addList('Otwarte pytania', protocol.open_questions || []);

    if (metaBox) {
      metaBox.textContent = `Źródło: ${fileName} · Wygenerowano: ${new Date().toLocaleString('pl-PL')}`;
    }

    resultSection.hidden = false;
    pdfBtn.hidden = false;
    jsonBtn.hidden = false;
  }

  function countItems(p) {
    return (p.topics || []).length + (p.decisions || []).length +
      (p.action_items || []).length + (p.open_questions || []).length;
  }

  async function generateProtocol() {
    const chunks = chunkText(sourceText);
    if (!chunks.length) {
      setMessage('Plik jest pusty lub nie zawiera tekstu.', 'error');
      return;
    }

    resultSection.hidden = true;
    pdfBtn.hidden = true;
    jsonBtn.hidden = true;
    generateBtn.disabled = true;

    try {
      const parts = [];

      for (let i = 0; i < chunks.length; i++) {
        setMessage(`Bielik wyciąga ustalenia z fragmentu ${i + 1} z ${chunks.length}… Proszę czekać.`);
        const data = await callBackend({ action: 'protocol_extract', text: chunks[i] });
        parts.push(data.protocol);
      }

      setMessage('Bielik łączy wyniki w jeden protokół…');
      const merged = await callBackend({ action: 'protocol_merge', parts });
      protocol = merged.protocol;

      renderProtocol();

      if (countItems(protocol) === 0) {
        setMessage('Model nie znalazł w tekście żadnych decyzji, zadań ani pytań.', 'success');
      } else {
        setMessage(`Protokół gotowy (przeanalizowano fragmentów: ${chunks.length}).`, 'success');
      }
    } catch (err) {
      setMessage('Błąd: ' + err.message, 'error');
    } finally {
      generateBtn.disabled = false;
    }
  }

  async function handleGenerate() {
    const file = fileInput && fileInput.files[0];

    if (file) {
      setMessage('Odczytywanie zawartości pliku...');
      try {
        sourceText = await readFile(file);
      } catch (err) {
        setMessage(err.message || 'Błąd ładowania pliku.', 'error');
        return;
      }
    } else if (!sourceText) {
      setMessage('Wybierz plik przed generowaniem protokołu.', 'error');
      return;
    }

    generateProtocol();
  }

  function loadHandoff() {
    try {
      const raw = sessionStorage.getItem(HANDOFF_KEY);
      if (!raw) return;
      sessionStorage.removeItem(HANDOFF_KEY);

      const data = JSON.parse(raw);
      if (data && typeof data.text === 'string' && data.text.trim()) {
        sourceText = data.text;
        fileName = data.name || 'tekst';
        setMessage(`Wczytano tekst z poprzedniego kroku (${fileName}). Kliknij przycisk generowania.`);
      }
    } catch (_) { /* brak sessionStorage / uszkodzone dane - ignoruj */ }
  }

  if (generateBtn) generateBtn.addEventListener('click', handleGenerate);

  if (fileInput) {
    fileInput.addEventListener('change', () => {
      const file = fileInput.files[0];
      sourceText = '';
      protocol = null;
      resultSection.hidden = true;
      pdfBtn.hidden = true;
      jsonBtn.hidden = true;
      if (file) setMessage(`Wybrany plik: ${file.name}. Kliknij przycisk generowania.`);
    });
  }

  // PDF: okno drukowania przeglądarki -> "Zapisz jako PDF" (poprawne polskie znaki).
  if (pdfBtn) {
    pdfBtn.addEventListener('click', () => {
      const oldTitle = document.title;
      document.title = `${fileName}-protokol`;
      window.print();
      document.title = oldTitle;
    });
  }

  if (jsonBtn) {
    jsonBtn.addEventListener('click', () => {
      if (!protocol) return;
      const blob = new Blob([JSON.stringify(protocol, null, 2)], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${fileName}-protokol.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  }

  loadHandoff();
  checkOllamaConnection();
})();
