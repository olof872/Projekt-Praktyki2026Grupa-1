<!doctype html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Protocol Generator</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="top"><a class="brand" href="index.php">Text Tools AI</a><a href="index.php">Strona główna</a> <a href="stutter-checker.php">Stutter Checker</a> <a href="language-checker.php">Language Checker</a></header>
<main class="container">
  <a href="index.php">← Powrót</a>
  <h1>Protocol Generator</h1>
  <p>Ollama wyciągnie ze stenogramu tematy, decyzje, zadania i otwarte pytania. Gotowy protokół zapiszesz jako PDF.</p>
  <p id="connection" class="status"></p>
  <input id="file" type="file" accept=".txt,.pdf,text/plain,application/pdf">
  <button id="generateProtocol">Wczytaj i generuj protokół</button>
  <p id="message" role="status"></p>
  <section id="protocolResult" class="panel" hidden>
    <h2 id="protocolTitle">Protokół i podsumowanie ustaleń</h2>
    <p id="protocolMeta"></p>
    <div id="protocolBody"></div>
  </section>
  <button id="downloadPdf" hidden>Pobierz protokół jako PDF</button>
  <button id="downloadJson" hidden>Pobierz JSON</button>
</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
<script src="protocol.js"></script>
</body>
</html>
