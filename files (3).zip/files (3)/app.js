(() => {
  'use strict';

  const $ = id => document.getElementById(id);

  const PDFJS_WORKER = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  const HANDOFF_KEY = 'textTools.handoff';   
  const BATCH_SIZE = 10;                     
  const MAX_SENTENCE_LEN = 1500;            

  const fileInput = $('file');
  const scanStutterBtn = $('scanStutter');
  const scanLanguageBtn = $('scanLanguage');
  const messageBox = $('message');
  const reviewSection = $('review');
  const counterLabel = $('counter');
  const snippetBox = $('snippet');
  const downloadBtn = $('download');
  const continueBtn = $('continue');
  const languageLabel = $('languageLabel');
  const reasonBox = $('reason');

  
  let globalText = '';
  let fileName = 'tekst';
  let detectedIssues = [];
  let currentPos = 0;
  let activeMode = ''; 

 
  const stutterRegex = /(?<!\p{L})([ye])\1+(?!\p{L})|(\p{L})\2{2,}/giu;

  function escapeHtml(str) {
    return str.replace(/[&<>"']/g, c => ({
      '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
  }

  function setMessage(text, cls = '') {
    if (!messageBox) return;
    messageBox.className = cls;
    messageBox.textContent = text;
  }

  if (window.pdfjsLib) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = PDFJS_WORKER;
  }

  async function callBackend(payload) {
    const res = await fetch('ollama.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    let data = null;
    try { data = await res.json(); } catch (_) { /* nie-JSON */ }

    if (!res.ok || !data || data.error) {
      throw new Error((data && data.error) || `Błąd serwera (HTTP ${res.status}).`);
    }
    return data;
  }

  async function checkOllamaConnection() {
    const connDiv = $('connection');
    if (!connDiv) return;

    connDiv.className = 'status';
    connDiv.textContent = 'Sprawdzanie połączenia z Ollama…';

    try {
      const data = await callBackend({ action: 'health' });
      connDiv.className = 'status success';
      connDiv.textContent = `Połączono z Ollama. Aktywny model: ${data.model}`;
    } catch (err) {
      connDiv.className = 'status error';
      connDiv.textContent = err.message || 'Brak połączenia z Ollama.';
    }
  }


  function scanForStutter() {
    detectedIssues = [];
    stutterRegex.lastIndex = 0;
    let match;

    while ((match = stutterRegex.exec(globalText)) !== null) {
      detectedIssues.push({
        start: match.index,
        end: match.index + match[0].length,
        value: match[0],
        replacement: match[1] ? '' : match[0].charAt(0),
        type: 'stutter'
      });
    }

    currentPos = 0;
    activeMode = 'stutter';
    setMessage(`Analiza ukończona. Znaleziono ${detectedIssues.length} ciągów.`);
    renderReview();
  }


  function segmentText(text) {
    const segments = [];
    let cursor = 0;

    for (const part of text.split(/(?<=[.!?])\s+|\n+/)) {
      const trimmed = part.trim();
      if (!trimmed) continue;

      const start = text.indexOf(trimmed, cursor);
      if (start === -1) continue;
      cursor = start + trimmed.length;

      if (!/\p{L}/u.test(trimmed)) continue; // liczby/znaki - nie ma czego klasyfikować

      for (let off = 0; off < trimmed.length; off += MAX_SENTENCE_LEN) {
        const piece = trimmed.slice(off, off + MAX_SENTENCE_LEN);
        segments.push({ text: piece, start: start + off, end: start + off + piece.length });
      }
    }
    return segments;
  }

  async function scanForForeignLanguage() {
    const segments = segmentText(globalText);
    if (!segments.length) {
      setMessage('Plik jest pusty lub nie zawiera tekstu.', 'error');
      return;
    }

    if (reviewSection) reviewSection.hidden = true;
    if (scanLanguageBtn) scanLanguageBtn.disabled = true;
    detectedIssues = [];

    try {
      for (let i = 0; i < segments.length; i += BATCH_SIZE) {
        const batch = segments.slice(i, i + BATCH_SIZE);
        setMessage(`Bielik analizuje zdania ${i + 1}–${i + batch.length} z ${segments.length}… Proszę czekać.`);

        const data = await callBackend({
          action: 'language',
          sentences: batch.map(s => s.text)
        });

        for (const item of data.results || []) {
          if (item.is_polish !== false) continue;
          const seg = batch[item.index];
          if (!seg) continue;

          detectedIssues.push({
            start: seg.start,
            end: seg.end,
            value: seg.text,
            replacement: '',
            language: item.language || 'Obcy',
            reason: item.reason || 'Zdanie napisane w innym języku.',
            type: 'language'
          });
        }
      }

      currentPos = 0;
      activeMode = 'language';
      setMessage(`Analiza ukończona. Wykryto ${detectedIssues.length} fragmentów obcojęzycznych.`);
      renderReview();
    } catch (err) {
      setMessage('Błąd: ' + err.message, 'error');
    } finally {
      if (scanLanguageBtn) scanLanguageBtn.disabled = false;
    }
  }

  function renderReview() {
    if (continueBtn) continueBtn.hidden = !globalText;

    if (!detectedIssues.length) {
      if (reviewSection) reviewSection.hidden = true;
      if (globalText) {
        setMessage(
          activeMode === 'stutter'
            ? 'Nie znaleziono powtarzających się liter. Plik jest czysty!'
            : 'Bielik nie wykrył żadnych obcych zdań. Cały tekst jest po polsku!',
          'success'
        );
      }
      if (downloadBtn) downloadBtn.hidden = !globalText;
      return;
    }

    if (reviewSection) reviewSection.hidden = false;
    if (downloadBtn) downloadBtn.hidden = false;

    if (counterLabel) {
      counterLabel.textContent = `Fragment ${currentPos + 1} z ${detectedIssues.length}`;
    }

    const issue = detectedIssues[currentPos];
    const contextRange = activeMode === 'stutter' ? 55 : 120;
    const startPos = Math.max(0, issue.start - contextRange);
    const endPos = Math.min(globalText.length, issue.end + contextRange);

    const before = globalText.slice(startPos, issue.start);
    const target = globalText.slice(issue.start, issue.end);
    const after = globalText.slice(issue.end, endPos);

    if (snippetBox) {
      snippetBox.innerHTML =
        (startPos > 0 ? '…' : '') +
        escapeHtml(before) +
        `<mark style="background:#5145d8; color:white; padding:2px 4px; border-radius:4px;">⟦${escapeHtml(target)}⟧</mark>` +
        escapeHtml(after) +
        (endPos < globalText.length ? '…' : '');
    }

    if (activeMode === 'language') {
      if (languageLabel) {
        languageLabel.hidden = false;
        languageLabel.textContent = `Wykryty język: ${issue.language}`;
      }
      if (reasonBox) {
        reasonBox.hidden = false;
        reasonBox.textContent = `Powód: ${issue.reason}`;
      }
    } else {
      if (languageLabel) languageLabel.hidden = true;
      if (reasonBox) reasonBox.hidden = true;
    }

    if ($('prev')) $('prev').disabled = currentPos === 0;
    if ($('next')) $('next').disabled = currentPos === detectedIssues.length - 1;
  }


  async function readFile(file) {
    const extension = file.name.split('.').pop().toLowerCase();
    fileName = file.name.replace(/\.[^.]+$/, '') || 'tekst';

    if (extension === 'txt') {
      return file.text();
    }

    if (extension === 'pdf') {
      if (!window.pdfjsLib) {
        throw new Error('Biblioteka PDF.js nie została załadowana. Sprawdź połączenie internetowe.');
      }
      const buffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(buffer) }).promise;
      const pages = [];

      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        pages.push(content.items.map(item => item.str).join(' '));
      }

      const text = pages.join('\n\n');
      if (!text.trim()) {
        throw new Error('PDF nie zawiera warstwy tekstowej (prawdopodobnie skan - wymaga OCR).');
      }
      return text;
    }

    throw new Error('Niedozwolony format pliku. Wybierz plik TXT lub PDF.');
  }

  async function handleFileLoad(callback) {
    const file = fileInput && fileInput.files[0];

    if (file) {
      setMessage('Odczytywanie zawartości pliku...');
      try {
        globalText = await readFile(file);
      } catch (err) {
        setMessage(err.message || 'Błąd ładowania pliku.', 'error');
        return;
      }
    } else if (!globalText) {
      setMessage('Wybierz plik przed uruchomieniem analizy.', 'error');
      return;
    }

    callback();
  }

  function loadHandoff() {
    if (!fileInput) return;
    try {
      const raw = sessionStorage.getItem(HANDOFF_KEY);
      if (!raw) return;
      sessionStorage.removeItem(HANDOFF_KEY);

      const data = JSON.parse(raw);
      if (data && typeof data.text === 'string' && data.text.trim()) {
        globalText = data.text;
        fileName = data.name || 'tekst';
        setMessage(`Wczytano tekst z poprzedniego kroku (${fileName}). Kliknij przycisk analizy.`);
        if (downloadBtn) downloadBtn.hidden = false;
        if (continueBtn) continueBtn.hidden = false;
      }
    } catch (_) { /* brak sessionStorage / uszkodzone dane - ignoruj */ }
  }


  if (scanStutterBtn) scanStutterBtn.addEventListener('click', () => handleFileLoad(scanForStutter));
  if (scanLanguageBtn) scanLanguageBtn.addEventListener('click', () => handleFileLoad(scanForForeignLanguage));

  if ($('keep')) {
    $('keep').addEventListener('click', () => {
      if (currentPos < detectedIssues.length - 1) {
        currentPos++;
        renderReview();
      }
    });
  }

  if ($('remove')) {
    $('remove').addEventListener('click', () => {
      if (!detectedIssues.length) return;

      const issue = detectedIssues[currentPos];
      const replacement = issue.replacement || '';
      const shift = (issue.end - issue.start) - replacement.length;

      globalText = globalText.slice(0, issue.start) + replacement + globalText.slice(issue.end);

      detectedIssues.forEach((other, idx) => {
        if (idx > currentPos) {
          other.start -= shift;
          other.end -= shift;
        }
      });

      detectedIssues.splice(currentPos, 1);
      currentPos = Math.max(0, Math.min(currentPos, detectedIssues.length - 1));
      setMessage('Fragment został usunięty z dokumentu.');
      renderReview();
    });
  }

  if ($('prev')) {
    $('prev').addEventListener('click', () => {
      if (currentPos > 0) {
        currentPos--;
        renderReview();
      }
    });
  }

  if ($('next')) {
    $('next').addEventListener('click', () => {
      if (currentPos < detectedIssues.length - 1) {
        currentPos++;
        renderReview();
      }
    });
  }

  if (downloadBtn) {
    downloadBtn.addEventListener('click', () => {
      const blob = new Blob([globalText], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${fileName}-poprawiony.txt`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  }

  
  if (continueBtn) {
    continueBtn.addEventListener('click', () => {
      try {
        sessionStorage.setItem(HANDOFF_KEY, JSON.stringify({ text: globalText, name: fileName }));
      } catch (_) {
        setMessage('Tekst jest za duży, by przekazać go dalej. Pobierz plik i wczytaj go ręcznie.', 'error');
        return;
      }
      window.location.href = continueBtn.dataset.next;
    });
  }

  if (fileInput) {
    fileInput.addEventListener('change', () => {
      const file = fileInput.files[0];
      globalText = '';
      detectedIssues = [];
      currentPos = 0;
      if (reviewSection) reviewSection.hidden = true;
      if (downloadBtn) downloadBtn.hidden = true;
      if (continueBtn) continueBtn.hidden = true;
      if (file) setMessage(`Wybrany plik: ${file.name}. Kliknij przycisk analizy.`);
    });
  }

  loadHandoff();
  checkOllamaConnection();
})();
