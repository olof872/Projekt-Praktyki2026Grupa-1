<!doctype html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Language Checker</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="top"><a class="brand" href="index.php">Text Tools AI</a><a href="index.php">Strona główna</a> <a href="stutter-checker.php">Stutter Checker</a> <a href="protocol.php">Protokół</a></header>
<main class="container">
  <a href="index.php">← Powrót</a>
  <h1>Language Checker</h1>
  <p>Ollama sprawdzi, które zdania mogą być napisane w języku innym niż polski.</p>
  <p id="connection" class="status"></p>
  <input id="file" type="file" accept=".txt,.pdf,text/plain,application/pdf">
  <button id="scanLanguage">Wczytaj i analizuj</button>
  <p id="message" role="status"></p>
  <section id="review" class="panel" hidden>
    <p id="counter"></p>
    <span id="languageLabel" class="pill"></span>
    <div id="snippet" class="snippet"></div>
    <p id="reason" style="margin-top: 10px; font-style: italic; color: #555;"></p>
    <div class="actions">
      <button id="prev">← Wstecz</button>
      <button id="keep" class="secondary">Zachowaj</button>
      <button id="remove" class="danger">Usuń zdanie</button>
      <button id="next">Dalej →</button>
    </div>
  </section>
  <button id="download" hidden>Pobierz oczyszczony TXT</button>
  <button id="continue" data-next="stutter-checker.php" hidden>Kontynuuj → Stutter Checker</button>
</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
<script src="app.js"></script>
</body>
</html>
