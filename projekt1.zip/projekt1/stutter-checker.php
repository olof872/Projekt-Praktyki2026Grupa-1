<!doctype html>
<html lang="pl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Stutter Checker</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="top"><a class="brand" href="index.php">Text Tools AI</a><a href="index.php">Strona główna</a> <a href="language-checker.php">Language Checker</a> <a href="protocol.php">Protokół</a></header>
<main class="container">
  <a href="index.php">← Powrót</a>
  <h1>Stutter Checker</h1>
  <p>Wczytaj TXT lub PDF. Przeglądaj powtarzane litery i zdecyduj, czy je usunąć.</p>
  <input id="file" type="file" accept=".txt,.pdf,text/plain,application/pdf">
  <button id="scanStutter">Analizuj plik</button>
  <p id="message" role="status"></p>
  <section id="review" class="panel" hidden>
    <p id="counter"></p>
    <div id="snippet" class="snippet"></div>
    <div class="actions">
      <button id="prev">← Wstecz</button>
      <button id="keep" class="secondary">Zachowaj</button>
      <button id="remove" class="danger">Usuń ciąg</button>
      <button id="next">Dalej →</button>
    </div>
  </section>
  <button id="download" hidden>Pobierz oczyszczony TXT</button>
  <button id="continue" data-next="language-checker.php" hidden>Kontynuuj → Language Checker</button>
</main>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
<script src="app.js"></script>
</body>
</html>
