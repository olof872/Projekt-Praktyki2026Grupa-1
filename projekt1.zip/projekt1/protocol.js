(() => {
  'use strict';
 
  const $ = id => document.getElementById(id);
 
  const PDFJS_WORKER = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  const HANDOFF_KEY = 'textTools.handoff';
  const CHUNK_SIZE = 2500; // znaków na jedno zapytanie (num_ctx = 4096, wejście + wyjście)
 
  const fileInput = $('file');
  const generateBtn = $('generateProtocol');
  const messageBox = $('message');
  const resultSection = $('protocolResult');
  const bodyBox = $('protocolBody');
  const metaBox = $('protocolMeta');
  const pdfBtn = $('downloadPdf');
  const jsonBtn = $('downloadJson');
 
  let sourceText = '';
  let fileName = 'tekst';
  let result = null;
 
  function setMessage(text, cls = '') {
    if (!messageBox) return;
    messageBox.className = cls;
    messageBox.textContent = text;
  }
 
  if (window.pdfjsLib) {
    pdfjsLib.GlobalWorkerOptions.workerSrc = PDFJS_WORKER;
  }
 
  async function callBackend(payload) {
    const res = await fetch('ollama.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
 
    let data = null;
    try { data = await res.json(); } catch (_) { /* nie-JSON */ }
 
    if (!res.ok || !data || data.error) {
      throw new Error((data && data.error) || `Błąd serwera (HTTP ${res.status}).`);
    }
    return data;
  }
 
  async function checkOllamaConnection() {
    const connDiv = $('connection');
    if (!connDiv) return;
 
    connDiv.className = 'status';
    connDiv.textContent = 'Sprawdzanie połączenia z Ollama…';
 
    try {
      const data = await callBackend({ action: 'health' });
      connDiv.className = 'status success';
      connDiv.textContent = `Połączono z Ollama. Aktywny model: ${data.model}`;
    } catch (err) {
      connDiv.className = 'status error';
      connDiv.textContent = err.message || 'Brak połączenia z Ollama.';
    }
  }
 
  async function readFile(file) {
    const extension = file.name.split('.').pop().toLowerCase();
    fileName = file.name.replace(/\.[^.]+$/, '') || 'tekst';
 
    if (extension === 'txt') {
      return file.text();
    }
 
    if (extension === 'pdf') {
      if (!window.pdfjsLib) {
        throw new Error('Biblioteka PDF.js nie została załadowana. Sprawdź połączenie internetowe.');
      }
      const buffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: new Uint8Array(buffer) }).promise;
      const pages = [];
 
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        pages.push(content.items.map(item => item.str).join(' '));
      }
 
      const text = pages.join('\n\n');
      if (!text.trim()) {
        throw new Error('PDF nie zawiera warstwy tekstowej (prawdopodobnie skan - wymaga OCR).');
      }
      return text;
    }
 
    throw new Error('Niedozwolony format pliku. Wybierz plik TXT lub PDF.');
  }
 
  // ---------- Podział tekstu ----------
 
  // Dzieli tekst na fragmenty po granicach zdań, żeby nie ucinać myśli w pół słowa.
  function chunkText(text) {
    const parts = text.split(/(?<=[.!?])\s+|\n+/).map(p => p.trim()).filter(Boolean);
    const chunks = [];
    let current = '';
 
    const flush = () => {
      if (current.trim()) chunks.push(current.trim());
      current = '';
    };
 
    for (const part of parts) {
      if (part.length > CHUNK_SIZE) {
        flush();
        for (let off = 0; off < part.length; off += CHUNK_SIZE) {
          chunks.push(part.slice(off, off + CHUNK_SIZE));
        }
        continue;
      }
      if (current.length + part.length + 1 > CHUNK_SIZE) flush();
      current += (current ? ' ' : '') + part;
    }
    flush();
    return chunks;
  }
 
  // Punkty obrad: dyrektor zapowiada je słowami "Przejdziemy teraz do <nazwa punktu>."
  function segmentSections(text) {
    const re = /Przejdziemy teraz do\s+([^.!?\n]+)[.!?]/giu;
    const marks = [];
    let m;
 
    while ((m = re.exec(text)) !== null) {
      const raw = m[1].trim();
      if (raw) {
        marks.push({ index: m.index, title: raw.charAt(0).toLocaleUpperCase('pl') + raw.slice(1) });
      }
    }
 
    if (!marks.length) {
      return [{ title: 'Przebieg posiedzenia', text: text.trim() }];
    }
 
    return marks
      .map((mark, i) => {
        const start = i === 0 ? 0 : mark.index; // wstęp przed pierwszym markerem należy do punktu 1
        const end = i + 1 < marks.length ? marks[i + 1].index : text.length;
        return { title: mark.title, text: text.slice(start, end).trim() };
      })
      .filter(s => /\p{L}/u.test(s.text));
  }
 
  function mergeTurns(turns) {
    const out = [];
    for (const t of turns) {
      const last = out[out.length - 1];
      if (last && last.speaker === t.speaker) {
        last.text += ' ' + t.text;
      } else {
        out.push({ speaker: t.speaker, text: t.text });
      }
    }
    return out;
  }
 
  // Wypowiedzi z etykietami "Mówca: tekst", pogrupowane w porcje mieszczące się w oknie modelu.
  function chunkTurns(turns) {
    const lines = [];
    for (const t of turns) {
      const label = `${t.speaker}: `;
      const room = Math.max(500, CHUNK_SIZE - label.length);
      for (let off = 0; off < t.text.length; off += room) {
        lines.push(label + t.text.slice(off, off + room));
      }
    }
 
    const chunks = [];
    let current = '';
    for (const line of lines) {
      if (current && current.length + line.length + 1 > CHUNK_SIZE) {
        chunks.push(current);
        current = '';
      }
      current += (current ? '\n' : '') + line;
    }
    if (current) chunks.push(current);
    return chunks;
  }
 
  function uniq(list) {
    const seen = new Set();
    return list.filter(item => {
      const key = String(item).toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }
 
  function mergeParts(parts) {
    const actions = [];
    const seen = new Set();
 
    parts.forEach(p => (p.action_items || []).forEach(a => {
      const key = `${a.who}|${a.task}`.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        actions.push(a);
      }
    }));
 
    const flat = key => [].concat(...parts.map(p => p[key] || []));
 
    return {
      summary: flat('summary'),
      decisions: uniq(flat('decisions')),
      action_items: actions,
      open_questions: uniq(flat('open_questions'))
    };
  }
 
  // ---------- Pipeline ----------
 
  async function processSection(section, index, total) {
    const label = `Punkt ${index + 1} z ${total}`;
 
    // Krok 1: podział na mówców + korekta błędów rozpoznawania mowy
    const chunks = chunkText(section.text);
    let turns = [];
    let fallback = false;
 
    for (let c = 0; c < chunks.length; c++) {
      setMessage(`${label}: „${section.title}” – mówcy i korekta błędów (część ${c + 1} z ${chunks.length})… Proszę czekać.`);
      const data = await callBackend({ action: 'stenogram_section', text: chunks[c], title: section.title });
      if (data.fallback) fallback = true;
      turns = turns.concat(data.turns || []);
    }
    turns = mergeTurns(turns);
 
    // Krok 2: protokół punktu (podsumowanie wypowiedzi, decyzje, zadania, pytania)
    const labelled = chunkTurns(turns);
    const parts = [];
 
    for (let c = 0; c < labelled.length; c++) {
      setMessage(`${label}: „${section.title}” – protokół ustaleń (część ${c + 1} z ${labelled.length})… Proszę czekać.`);
      const data = await callBackend({ action: 'protocol_extract', text: labelled[c] });
      parts.push(data.protocol);
    }
 
    return { title: section.title, turns, fallback, ...mergeParts(parts) };
  }
 
  async function generateProtocol() {
    const sections = segmentSections(sourceText);
    if (!sections.length || !sections.some(s => s.text)) {
      setMessage('Plik jest pusty lub nie zawiera tekstu.', 'error');
      return;
    }
 
    resultSection.hidden = true;
    pdfBtn.hidden = true;
    jsonBtn.hidden = true;
    generateBtn.disabled = true;
 
    try {
      const done = [];
      for (let i = 0; i < sections.length; i++) {
        done.push(await processSection(sections[i], i, sections.length));
      }
 
      result = { topics: done.map(s => s.title), sections: done };
      renderResult();
 
      const fallbacks = done.filter(s => s.fallback).length;
      const found = done.reduce((n, s) =>
        n + s.decisions.length + s.action_items.length + s.open_questions.length, 0);
 
      if (fallbacks) {
        setMessage(`Gotowe, ale w punktach: ${fallbacks} model nie podzielił tekstu na mówców (pokazano go w całości, nic nie zginęło).`, 'success');
      } else if (!found) {
        setMessage('Gotowe. Model nie znalazł w tekście żadnych decyzji, zadań ani pytań.', 'success');
      } else {
        setMessage(`Protokół gotowy (punktów obrad: ${done.length}).`, 'success');
      }
    } catch (err) {
      setMessage('Błąd: ' + err.message, 'error');
    } finally {
      generateBtn.disabled = false;
    }
  }
 
  // ---------- Widok (tylko textContent, bez innerHTML) ----------
 
  function el(tag, text, cls) {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = text;
    if (cls) node.className = cls;
    return node;
  }
 
  function paragraph() {
    const p = el('p');
    p.style.cssText = 'margin:0 0 10px; font-size:14px; line-height:1.6;';
    return p;
  }
 
  function addLabelledList(label, items) {
    const p = paragraph();
    p.appendChild(el('strong', label));
    bodyBox.appendChild(p);
    const ul = el('ul');
    items.forEach(item => ul.appendChild(el('li', item)));
    bodyBox.appendChild(ul);
  }
 
  function addSummary(items) {
    const ul = el('ul');
    items.forEach(item => {
      const li = el('li');
      if (item.speaker) {
        li.appendChild(el('strong', item.speaker));
        li.appendChild(document.createTextNode(': '));
      }
      li.appendChild(document.createTextNode(item.text));
      ul.appendChild(li);
    });
    bodyBox.appendChild(ul);
  }
 
  function addActionsList(items) {
    const p = paragraph();
    p.appendChild(el('strong', 'Zadania do wykonania:'));
    bodyBox.appendChild(p);
 
    const ul = el('ul');
    items.forEach(item => {
      const li = el('li');
      if (item.who) {
        li.appendChild(el('strong', item.who));
        li.appendChild(document.createTextNode(': '));
      }
      li.appendChild(document.createTextNode(item.task));
      if (item.deadline) {
        li.appendChild(document.createTextNode(` (termin: ${item.deadline})`));
      }
      ul.appendChild(li);
    });
    bodyBox.appendChild(ul);
  }
 
  function renderResult() {
    bodyBox.textContent = '';
 
    // Część 1: stenogram z podziałem na punkty i mówców
    bodyBox.appendChild(el('h3', 'STENOGRAM ZE SPOTKANIA'));
 
    result.sections.forEach((section, i) => {
      bodyBox.appendChild(el('h3', `${i + 1}. ${section.title}`));
 
      section.turns.forEach(turn => {
        const p = paragraph();
        p.appendChild(document.createTextNode('Wypowiada się: '));
        p.appendChild(el('strong', turn.speaker));
        p.appendChild(document.createTextNode(' ' + turn.text));
        bodyBox.appendChild(p);
      });
    });
 
    // Część 2: protokół ustaleń
    bodyBox.appendChild(el('h3', 'PROTOKÓŁ I PODSUMOWANIE USTALEŃ ZE SPOTKANIA'));
    addLabelledList('Tematy posiedzenia:', result.topics);
 
    result.sections.forEach((section, i) => {
      bodyBox.appendChild(el('h3', `${i + 1}. ${section.title}`));
 
      if (section.fallback) {
        bodyBox.appendChild(el('p', 'Model nie podzielił tego punktu na mówców; tekst pokazano w całości.', 'empty'));
      }
      if (section.summary.length) addSummary(section.summary);
      if (section.decisions.length) addLabelledList('Decyzje i ustalenia:', section.decisions);
      if (section.action_items.length) addActionsList(section.action_items);
      if (section.open_questions.length) addLabelledList('Otwarte pytania:', section.open_questions);
 
      if (!section.summary.length && !section.decisions.length &&
          !section.action_items.length && !section.open_questions.length) {
        bodyBox.appendChild(el('p', 'Brak informacji w tekście.', 'empty'));
      }
    });
 
    if (metaBox) {
      metaBox.textContent = `Źródło: ${fileName} · Wygenerowano: ${new Date().toLocaleString('pl-PL')}`;
    }
 
    resultSection.hidden = false;
    pdfBtn.hidden = false;
    jsonBtn.hidden = false;
  }
 
  // ---------- Zdarzenia ----------
 
  async function handleGenerate() {
    const file = fileInput && fileInput.files[0];
 
    if (file) {
      setMessage('Odczytywanie zawartości pliku...');
      try {
        sourceText = await readFile(file);
      } catch (err) {
        setMessage(err.message || 'Błąd ładowania pliku.', 'error');
        return;
      }
    } else if (!sourceText) {
      setMessage('Wybierz plik przed generowaniem protokołu.', 'error');
      return;
    }
 
    generateProtocol();
  }
 
  function loadHandoff() {
    try {
      const raw = sessionStorage.getItem(HANDOFF_KEY);
      if (!raw) return;
      sessionStorage.removeItem(HANDOFF_KEY);
 
      const data = JSON.parse(raw);
      if (data && typeof data.text === 'string' && data.text.trim()) {
        sourceText = data.text;
        fileName = data.name || 'tekst';
        setMessage(`Wczytano tekst z poprzedniego kroku (${fileName}). Kliknij przycisk generowania.`);
      }
    } catch (_) { /* brak sessionStorage / uszkodzone dane - ignoruj */ }
  }
 
  if (generateBtn) generateBtn.addEventListener('click', handleGenerate);
 
  if (fileInput) {
    fileInput.addEventListener('change', () => {
      const file = fileInput.files[0];
      sourceText = '';
      result = null;
      resultSection.hidden = true;
      pdfBtn.hidden = true;
      jsonBtn.hidden = true;
      if (file) setMessage(`Wybrany plik: ${file.name}. Kliknij przycisk generowania.`);
    });
  }
 
  // PDF: okno drukowania przeglądarki -> "Zapisz jako PDF" (poprawne polskie znaki).
  if (pdfBtn) {
    pdfBtn.addEventListener('click', () => {
      const oldTitle = document.title;
      document.title = `${fileName}-protokol`;
      window.print();
      document.title = oldTitle;
    });
  }
 
  if (jsonBtn) {
    jsonBtn.addEventListener('click', () => {
      if (!result) return;
      const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${fileName}-protokol.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    });
  }
 
  loadHandoff();
  checkOllamaConnection();
})();